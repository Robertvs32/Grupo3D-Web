<?php
    $texto_Sobre = $_POST['textoSobre'];
    $imagem_Sobre = $_FILES['imgSobre'];
    $caminho_db = NULL;

    if(isset($imagem_Sobre) && $imagem_Sobre['error'] === UPLOAD_ERR_OK){
        $caminhoTemporario = $imagem_Sobre['tmp_name'];
        $extensao = pathinfo($imagem_Sobre['name'], PATHINFO_EXTENSION);
        $caminho_final = '../uploads/imagemSobre' . '.' . strtolower($extensao);
        
        if(move_uploaded_file($caminhoTemporario, $caminho_final)){
            $caminho_db = './uploads/imagemSobre' . '.' . strtolower($extensao);  
        }
    }
    try{
        require_once './connectiondb.php';
    
        if($texto_Sobre != ''){
            $sql = "UPDATE sobre set texto = :texto_Sobre where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':texto_Sobre', $texto_Sobre);
            $stmt->execute();
        }
        if($caminho_db !== NULL){
            $sql = "UPDATE sobre set imagem = :caminho_db where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':caminho_db', $caminho_db);
            $stmt->execute();
        }
    }catch(PDOException $e){
        echo"Erro ao enviar para o banco de dados!" . $e->getMessage();
    }
?>