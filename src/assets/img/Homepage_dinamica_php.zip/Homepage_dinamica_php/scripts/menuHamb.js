const btnHamb = document.getElementById('btnHamb');
const navHeader = document.getElementById('navHeader');

btnHamb.addEventListener('click', () => {
    navHeader.classList.toggle('navHeaderActive');
});