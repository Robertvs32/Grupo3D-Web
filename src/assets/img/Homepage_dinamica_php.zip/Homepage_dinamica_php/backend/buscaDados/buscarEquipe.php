<?php
    try{
        require_once './backend/connectiondb.php';

        $sql = "SELECT * from equipe";
        $stmt = $pdo->query($sql);
        $funcionarios =  $stmt->fetchAll();
        
    } catch(PDOException $e){
        die("Erro ao buscar depoimentos" . $e);
    }

    $nomeFunc1 = $funcionarios[0]['nome'];
    $textoFunc1 = $funcionarios[0]['texto'];
    $instaFunc1 = $funcionarios[0]['instagram'];
    $imgFunc1 = $funcionarios[0]['imagem'];

    $nomeFunc2 = $funcionarios[1]['nome'];
    $textoFunc2 = $funcionarios[1]['texto'];
    $instaFunc2 = $funcionarios[1]['instagram'];
    $imgFunc2 = $funcionarios[1]['imagem'];
?>

