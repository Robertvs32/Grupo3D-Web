

const formEquipe = document.getElementById('formEquipe');
const btnEquipe = document.getElementById('btnEquipe');
const urlEquipe = './backend/enviarEquipe.php';

const nomeFunc1 = document.getElementById('nomeFunc1');
const textoFunc1 = document.getElementById('textoFunc1');
const instaFunc1 = document.getElementById('instaFunc1');
const imgFunc1 = document.getElementById('imgFunc1');

const nomeFunc2 = document.getElementById('nomeFunc2');
const textoFunc2 = document.getElementById('textoFunc2');
const instaFunc2 = document.getElementById('instaFunc2');
const imgFunc2 = document.getElementById('imgFunc2');

btnEquipe.addEventListener('click', async (event) => {

    event.preventDefault();

    try{
        const formData = new FormData(formEquipe);

        const response = await fetch(urlEquipe, {
            method: 'POST',
            body: formData
        });

        if(response.ok){
            alert("Equipe atualizada com sucesso!");
            nomeFunc1.value = '';
            textoFunc1.value = '';
            instaFunc1.value = '';
            imgFunc1.value = '';

            nomeFunc2.value = '';
            textoFunc2.value = '';
            instaFunc2.value = '';
            imgFunc2.value = '';
        }
    }catch(error){
        alert(`Erro ao atualizar hero! ${error}`);
    }
});