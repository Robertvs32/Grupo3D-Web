const formHero = document.getElementById('formHero');
const btnHero = document.getElementById('btnHero');
const urlHero = './backend/enviarHero.php';

const tituloHero = document.getElementById('tituloHero');
const textoHero = document.getElementById('textoHero');
const imgHero = document.getElementById('imgHero');
const trixHero = document.getElementById('trixHero');


btnHero.addEventListener('click', async (event) => {

    event.preventDefault();

    try{
        const formData = new FormData(formHero);

        const response = await fetch(urlHero, {
            method: 'POST',
            body: formData
        });

        if(response.ok){
            alert("Hero atualizado com sucesso!");
            tituloHero.value = '';
            textoHero.value = '';
            imgHero.value = '';
            trixHero.innerHTML = '';
        }
    }catch(error){
        alert(`Erro ao atualizar hero! ${error}`);
    }
});