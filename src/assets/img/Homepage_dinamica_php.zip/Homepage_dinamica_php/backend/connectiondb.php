<?php
    $host = 'localhost';
    $user = 'root';
    $password = '';
    $db = 'homepage';

    $dsn = "mysql:host=$host;dbname=$db;charset=utf8";

    try {
        $pdo = new PDO($dsn, $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    } catch(PDOException $e){
        echo "Erro de conexão" . $e->getMessage();
        die();
    }
?>