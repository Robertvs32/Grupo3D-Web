<?php
    $nomeDepoimento1 = $_POST['nomeDepoimento1'];
    $textoDepoimento1 = $_POST['textoDepoimento1'];
    $imgDepoimento1 = $_FILES['imgDepoimento1'];

    $nomeDepoimento2 = $_POST['nomeDepoimento2'];
    $textoDepoimento2 = $_POST['textoDepoimento2'];
    $imgDepoimento2 = $_FILES['imgDepoimento2'];

    $caminhoImg1 = NULL;
    $caminhoImg2 = NULL;

    if(isset($imgDepoimento1) && $imgDepoimento1['error'] === UPLOAD_ERR_OK){
        $caminhoTemporario = $imgDepoimento1['tmp_name'];
        $extensao = pathinfo($imgDepoimento1['name'], PATHINFO_EXTENSION);
        $caminho_final = '../uploads/imagemDepoimento1' . '.' . strtolower($extensao);
        
        if(move_uploaded_file($caminhoTemporario, $caminho_final)){
            $caminhoImg1 = './uploads/imagemDepoimento1' . '.' . strtolower($extensao);  
        }
    }

    if(isset($imgDepoimento2) && $imgDepoimento2['error'] === UPLOAD_ERR_OK){
        $caminhoTemporario = $imgDepoimento2['tmp_name'];
        $extensao = pathinfo($imgDepoimento2['name'], PATHINFO_EXTENSION);
        $caminho_final = '../uploads/imagemDepoimento2' . '.' . strtolower($extensao);
        
        if(move_uploaded_file($caminhoTemporario, $caminho_final)){
            $caminhoImg2 = './uploads/imagemDepoimento2' . '.' . strtolower($extensao);  
        }
    }

    try{
        require_once './connectiondb.php';
    
        if($nomeDepoimento1 != ''){
            $sql = "UPDATE depoimentos set nome = :nomeDepoimento1 where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':nomeDepoimento1', $nomeDepoimento1);
            $stmt->execute();
        }
        if($nomeDepoimento2 != ''){
            $sql = "UPDATE depoimentos set nome = :nomeDepoimento2 where id = 2";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':nomeDepoimento2', $nomeDepoimento2);
            $stmt->execute();
        }
        if($textoDepoimento1 != ''){
            $sql = "UPDATE depoimentos set depoimento = :textoDepoimento1 where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':textoDepoimento1', $textoDepoimento1);
            $stmt->execute();
        }
        if($textoDepoimento2 != ''){
            $sql = "UPDATE depoimentos set depoimento = :textoDepoimento2 where id = 2";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':textoDepoimento2', $textoDepoimento2);
            $stmt->execute();
        }
        if($caminhoImg1 !== NULL){
            $sql = "UPDATE depoimentos set imagem = :caminhoImg1 where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':caminhoImg1', $caminhoImg1);
            $stmt->execute();
        }
        if($caminhoImg2 !== NULL){
            $sql = "UPDATE depoimentos set imagem = :caminhoImg2 where id = 2";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':caminhoImg2', $caminhoImg2);
            $stmt->execute();
        }
    }catch(PDOException $e){
        echo"Erro ao enviar para o banco de dados!" . $e->getMessage();
    }
?>