<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/painel.css">
    <link rel="stylesheet" href="./css/header.css">
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/trix@2.0.8/dist/trix.css">
    <script type="text/javascript" src="https://unpkg.com/trix@2.0.8/dist/trix.umd.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Onest:wght@100..900&display=swap" rel="stylesheet">
    <script src="./scripts/menuHamb.js" defer></script>
    <script src="./scripts/envioFormularios/enviarHero.js" defer></script>
    <script src="./scripts/envioFormularios/enviarDepoimentos.js" defer></script>
    <script src="./scripts/envioFormularios/enviarSobre.js" defer></script>
    <script src="./scripts/envioFormularios/enviarInfos.js" defer></script>
    <script src="./scripts/envioFormularios/enviarEquipe.js" defer></script>
</head>
<body>
    <?php include './includes/header.php'?>
    <?php include './includes/painel/heroPainel.php'?>
    <?php include './includes/painel/depoimentosPainel.php'?>
    <?php include './includes/painel/sobrePainel.php'?>
    <?php include './includes/painel/infosPainel.php'?>
    <?php include './includes/painel/equipePainel.php'?>
    

</body>
</html>