<h2 class=tituloSecao>HERO</h2>

<form id="formHero" class="forms">
    <label for="tituloHero" class="labelForm">Titulo hero</label>
    <input id="tituloHero" name="tituloHero" class="inputForm" type="text">
    
    <label for="textoHero" class="labelForm"></label>
    <input id="textoHero" name="textoHero" class="inputForm" type="hidden">
    <trix-toolbar  id="toolbarHero" class="toolbarStyle"></trix-toolbar>
    <trix-editor id="trixHero" class="editorTrix" input="textoHero" toolbar="toolbarHero"></trix-editor>

    <label for="imgHero" class="labelForm">Imagem de fundo</label>
    <input id="imgHero" class="inputFile" name="imgHero" type="file">

    <div class="btns">
        <button id="btnHero" type="submit">Atualizar</button>
        <button type="reset">Limpar</button>
    </div>
</form>