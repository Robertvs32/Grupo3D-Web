<?php
    $titulo_Hero = $_POST['tituloHero'];
    $texto_Hero = $_POST['textoHero'];
    $imagem_Hero = $_FILES['imgHero'];
    $caminho_db = NULL;

    if(isset($imagem_Hero) && $imagem_Hero['error'] === UPLOAD_ERR_OK){
        $caminhoTemporario = $imagem_Hero['tmp_name'];
        $extensao = pathinfo($imagem_Hero['name'], PATHINFO_EXTENSION);
        $caminho_final = '../uploads/imagemHero' . '.' . strtolower($extensao);
        
        if(move_uploaded_file($caminhoTemporario, $caminho_final)){
            $caminho_db = './uploads/imagemHero' . '.' . strtolower($extensao);  
        }
    }
    try{
        require_once './connectiondb.php';
    
        if($titulo_Hero != ''){
            $sql = "UPDATE hero set tituloHero = :titulo_Hero where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':titulo_Hero', $titulo_Hero);
            $stmt->execute();
        }
        if($texto_Hero != ''){
            $sql = "UPDATE hero set textoHero = :texto_Hero where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':texto_Hero', $texto_Hero);
            $stmt->execute();
        }
        if($caminho_db !== NULL){
            $sql = "UPDATE hero set imgUrl = :caminho_db where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':caminho_db', $caminho_db);
            $stmt->execute();
        }
    }catch(PDOException $e){
        echo"Erro ao enviar para o banco de dados!" . $e->getMessage();
    }
?>