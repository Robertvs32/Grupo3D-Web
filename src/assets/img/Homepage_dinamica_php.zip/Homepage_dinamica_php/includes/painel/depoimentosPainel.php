<h2 class=tituloSecao>DEPOIMENTOS</h2>

<form id="formDepoimentos" class="forms">

    <p class="separadorCampos">Depoimento 1</p>

    <label for="nomeDepoimento1" class="labelForm">Nome</label>
    <input id="nomeDepoimento1" name="nomeDepoimento1" class="inputForm" type="text">
    
    <label for="textoDepoimento1" class="labelForm">Depoimento</label>
    <input id="textoDepoimento1" name="textoDepoimento1" class="inputForm" type="hidden">
    <trix-toolbar id="toolbarDepoimento1" class="toolbarStyle"></trix-toolbar>
    <trix-editor id="trixDepoimento1" class="editorTrix" input="textoDepoimento1" toolbar="toolbarDepoimento1"></trix-editor>

    <label for="imgDepoimento1" class="labelForm">Imagem perfil</label>
    <input id="imgDepoimento1" class="inputFile" name="imgDepoimento1" type="file">

    <p class="separadorCampos">Depoimento 2</p>

    <label for="nomeDepoimento2" class="labelForm">Nome</label>
    <input id="nomeDepoimento2" name="nomeDepoimento2" class="inputForm" type="text">
    
    <label for="textoDepoimento2" class="labelForm">Depoimento</label>
    <input id="textoDepoimento2" name="textoDepoimento2" class="inputForm" type="hidden">
    <trix-toolbar id="toolbarDepoimento2" class="toolbarStyle"></trix-toolbar>
    <trix-editor id="trixDepoimento2" class="editorTrix" input="textoDepoimento2" toolbar="toolbar"></trix-editor>

    <label for="imgDepoimento2" class="labelForm">Imagem perfil</label>
    <input id="imgDepoimento2" class="inputFile" name="imgDepoimento2" type="file">

    <div class="btns">
        <button id="btnDepoimentos">Atualizar</button>
        <button type="reset">Limpar</button>
    </div>
</form>