<h2 class=tituloSecao>INFORMAÇÕES</h2>

<form id="formInfos" class="forms">
    <label for="telefoneInfos" class="labelForm">Telefone</label>
    <input id="telefoneInfos" name="telefoneInfos" class="inputForm" type="text">
    
    <label for="celularInfo" class="labelForm">Celular</label>
    <input id="celularInfos" name="celularInfos" class="inputForm" type="text">

    <label for="enderecoInfo" class="labelForm">Endereço</label>
    <input id="enderecoInfos" name="enderecoInfos" class="inputForm" type="text">

    <label for="imgInfos" class="labelForm">Imagem do local</label>
    <input id="imgInfos" class="inputFile" name="imgInfos" type="file">

    <div class="btns">
        <button id="btnInfos" type="submit">Atualizar</button>
        <button type="reset">Limpar</button>
    </div>
</form>