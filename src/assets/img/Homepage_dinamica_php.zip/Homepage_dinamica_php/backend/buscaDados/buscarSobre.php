<?php
    try{
        require_once './backend/connectiondb.php';

        $sql = "SELECT * from sobre";
        $stmt = $pdo->query($sql);
        $sobre =  $stmt->fetch();
        
    } catch(PDOException $e){
        die("Erro ao buscar depoimentos" . $e);
    }

    $textoSobre = $sobre['texto'];
    $imagemSobre = $sobre['imagem'];  
?>