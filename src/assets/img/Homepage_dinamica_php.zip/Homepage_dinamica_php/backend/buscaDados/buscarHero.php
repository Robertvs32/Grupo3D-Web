<?php
    try{
        require_once './backend/connectiondb.php';

        $sql = "SELECT * from hero";
        $stmt = $pdo->query($sql);
        $hero =  $stmt->fetch();
        
    } catch(PDOException $e){
        die("Erro ao buscar depoimentos" . $e);
    }

    $tituloHero = $hero['tituloHero'];
    $textoHero = $hero['textoHero'];
    $imgHero = $hero['imgUrl'];

?>
