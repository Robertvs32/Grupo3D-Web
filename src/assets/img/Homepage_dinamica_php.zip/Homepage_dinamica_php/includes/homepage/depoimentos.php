<div id="depoimentos">

    <h2 id="titleDepoimentos">Depoimentos</h2>

    <div class="cardDepoimentos">
        <img class="imgCardDepoimentos" src="<?php echo $imagemDepoimento1 ?>" alt="">
        <h3 class="titleCardDepoimentos"><?php echo $nome_depoimento1 ?></h3>
        <p class="textDepoimentos"><?php echo $depoimento1 ?></p>
    </div>

    <div class="cardDepoimentos">
        <img class="imgCardDepoimentos" src="<?php echo $imagemDepoimento2 ?>" alt="">
        <h3 class="titleCardDepoimentos"><?php echo $nome_depoimento2 ?></h3>
        <p class="textDepoimentos"><?php echo $depoimento2 ?></p>
    </div>
</div>