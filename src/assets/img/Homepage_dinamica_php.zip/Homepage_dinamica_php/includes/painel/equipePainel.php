<h2 class=tituloSecao>EQUIPE</h2>

<form id="formEquipe" class="forms">
    
    <p class="separadorCampos">Funcionário 1</p>
    <label for="nomeFunc1" class="labelForm">Nome</label>
    <input id="nomeFunc1" name="nomeFunc1" class="inputForm" type="text">

    <label for="textoFunc1" class="labelForm">Breve texto</label>
    <input id="textoFunc1" name="textoFunc1" class="inputForm" type="text">

    <label for="instaFunc1" class="labelForm">Instagram</label>
    <input id="instaFunc1" name="instaFunc1" class="inputForm" type="text">

    <label for="imgFunc1" class="labelForm">Imagem do funcionário</label>
    <input id="imgFunc1" class="inputFile" name="imgFunc1" type="file">

    <p class="separadorCampos">Funcionário 2</p>

    <label for="nomeFunc2" class="labelForm">Nome</label>
    <input id="nomeFunc2" name="nomeFunc2" class="inputForm" type="text">

    <label for="textoFunc2" class="labelForm">Breve texto</label>
    <input id="textoFunc2" name="textoFunc2" class="inputForm" type="text">

    <label for="instaFunc2" class="labelForm">Instagram</label>
    <input id="instaFunc2" name="instaFunc2" class="inputForm" type="text">

    <label for="imgFunc2" class="labelForm">Imagem do funcionário</label>
    <input id="imgFunc2" class="inputFile" name="imgFunc2" type="file">

    <div class="btns">
        <button id="btnEquipe" type="submit">Atualizar</button>
        <button type="reset">Limpar</button>
    </div>
</form>