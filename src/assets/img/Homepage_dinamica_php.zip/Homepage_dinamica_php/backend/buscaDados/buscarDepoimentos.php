<?php
    try{
        require_once './backend/connectiondb.php';

        $sql = "SELECT * from depoimentos";
        $stmt = $pdo->query($sql);
        $depoimentos =  $stmt->fetchAll();

    } catch(PDOException $e){
        die("Erro ao buscar depoimentos" . $e);
    }

    $nome_depoimento1 = $depoimentos[0]['nome'];
    $nome_depoimento2 = $depoimentos[1]['nome'];

    $depoimento1 = $depoimentos[0]['depoimento'];
    $depoimento2 = $depoimentos[1]['depoimento'];

    $imagemDepoimento1 = $depoimentos[0]['imagem'];
    $imagemDepoimento2 = $depoimentos[1]['imagem'];
?>