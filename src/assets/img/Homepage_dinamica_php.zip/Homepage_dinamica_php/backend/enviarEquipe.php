<?php
    $nome_Func1 = $_POST['nomeFunc1'];
    $texto_Func1 = $_POST['textoFunc1'];
    $insta_Func1 = $_POST['instaFunc1'];
    $imagem_Func1 = $_FILES['imgFunc1'];

    $nome_Func2 = $_POST['nomeFunc2'];
    $texto_Func2 = $_POST['textoFunc2'];
    $insta_Func2 = $_POST['instaFunc2'];
    $imagem_Func2 = $_FILES['imgFunc2'];

    $caminho_Img1 = NULL;
    $caminho_Img2 = NULL;

    if(isset($imagem_Func1) && $imagem_Func1['error'] === UPLOAD_ERR_OK){
        $caminhoTemporario = $imagem_Func1['tmp_name'];
        $extensao = pathinfo($imagem_Func1['name'], PATHINFO_EXTENSION);
        $caminho_final = '../uploads/imagemFunc1' . '.' . strtolower($extensao);
        
        if(move_uploaded_file($caminhoTemporario, $caminho_final)){
            $caminho_Img1 = './uploads/imagemFunc1' . '.' . strtolower($extensao);  
        }
    }

    if(isset($imagem_Func2) && $imagem_Func2['error'] === UPLOAD_ERR_OK){
        $caminhoTemporario = $imagem_Func2['tmp_name'];
        $extensao = pathinfo($imagem_Func2['name'], PATHINFO_EXTENSION);
        $caminho_final = '../uploads/imagemFunc2' . '.' . strtolower($extensao);
        
        if(move_uploaded_file($caminhoTemporario, $caminho_final)){
            $caminho_Img2 = './uploads/imagemFunc2' . '.' . strtolower($extensao);  
        }
    }

    try{
        require_once './connectiondb.php';
    
        if($nome_Func1 != ''){
            $sql = "UPDATE equipe set nome = :nome_Func1 where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':nome_Func1', $nome_Func1);
            $stmt->execute();
        }
        if($nome_Func2 != ''){
            $sql = "UPDATE equipe set nome = :nome_Func2 where id = 2";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':nome_Func2', $nome_Func2);
            $stmt->execute();
        }
        if($texto_Func1 != ''){
            $sql = "UPDATE equipe set texto = :texto_Func1 where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':texto_Func1', $texto_Func1);
            $stmt->execute();
        }
        if($texto_Func2 != ''){
            $sql = "UPDATE equipe set texto = :texto_Func2 where id = 2";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':texto_Func2', $texto_Func2);
            $stmt->execute();
        }
        if($insta_Func1 != ''){
            $sql = "UPDATE equipe set instagram = :insta_Func1 where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':insta_Func1', $insta_Func1);
            $stmt->execute();
        }
        if($insta_Func2 != ''){
            $sql = "UPDATE equipe set instagram = :insta_Func2 where id = 2";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':insta_Func2', $insta_Func2);
            $stmt->execute();
        }
        if($caminho_Img1){
            $sql = "UPDATE equipe set imagem = :caminho_Img1 where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':caminho_Img1', $caminho_Img1);
            $stmt->execute();
        }
        if($caminho_Img2){
            $sql = "UPDATE equipe set imagem = :caminho_Img2 where id = 2";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':caminho_Img2', $caminho_Img2);
            $stmt->execute();
        }
    }catch(PDOException $e){
        echo"Erro ao enviar para o banco de dados!" . $e->getMessage();
    }
?>