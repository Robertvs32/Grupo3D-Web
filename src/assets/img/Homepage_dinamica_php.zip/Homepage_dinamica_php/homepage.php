<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nome da página</title>
    <link rel="stylesheet" href="./css/index.css">
    <link rel="stylesheet" href="./css/header.css">
    <link rel="stylesheet" href="./css/hero.css">
    <link rel="stylesheet" href="./css/sobre.css">
    <link rel="stylesheet" href="./css/equipe.css">
    <link rel="stylesheet" href="./css/depoimentos.css">
    <link rel="stylesheet" href="./css/infos.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Onest:wght@100..900&display=swap" rel="stylesheet">
    <script src="./scripts/menuHamb.js" defer></script>
</head>

<?php require_once './backend/connectiondb.php'?>

<?php require_once './backend/buscaDados/buscarDepoimentos.php'?>
<?php require_once './backend/buscaDados/buscarEquipe.php'?>
<?php require_once './backend/buscaDados/buscarHero.php'?>
<?php require_once './backend/buscaDados/buscarInfos.php'?>
<?php require_once './backend/buscaDados/buscarSobre.php'?>


<body>

    <?php include './includes/header.php'?>
    <?php include './includes/homepage/hero.php'?>
    <?php include './includes/homepage/sobre.php'?>
    <?php include './includes/homepage/equipe.php'?>
    <?php include './includes/homepage/depoimentos.php'?>
    <?php include './includes/homepage/infos.php'?>
    
</body>
</html>