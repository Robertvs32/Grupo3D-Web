const formDepoimentos = document.getElementById('formDepoimentos');
const btnDepoimentos = document.getElementById('btnDepoimentos');
const urlDepoimentos = './backend/enviarDepoimentos.php';

const nomeDepoimento1 = document.getElementById('nomeDepoimento1');
const textoDepoimento1 = document.getElementById('textoDepoimento1');
const imgDepoimento1 = document.getElementById('imgDepoimento1');
const trixDepoimento1 = document.getElementById('trixDepoimento1');

const nomeDepoimento2 = document.getElementById('nomeDepoimento2');
const textoDepoimento2 = document.getElementById('textoDepoimento2');
const imgDepoimento2 = document.getElementById('imgDepoimento2');
const trixDepoimento2 = document.getElementById('trixDepoimento2');


btnDepoimentos.addEventListener('click', async (event) => {

    event.preventDefault();

    try{
        const formData = new FormData(formDepoimentos);

        const response = await fetch(urlDepoimentos, {
            method: 'POST',
            body: formData
        });

        if(response.ok){
            alert("Depoimentos atualizados com sucesso!");
            nomeDepoimento1.value = '';
            textoDepoimento1.value = '';
            imgDepoimento1.value = '';
            trixDepoimento1.innerHTML = '';

            nomeDepoimento2.value = '';
            textoDepoimento2.value = '';
            imgDepoimento2.value = '';
            trixDepoimento2.innerHTML = '';
        }
    }catch(error){
        alert(`Erro ao atualizar depoimentos! ${error}`);
    }
});
