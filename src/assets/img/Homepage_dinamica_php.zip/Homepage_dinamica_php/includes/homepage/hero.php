<div id="hero" style="background-image: url(<?php echo $imgHero?>)">
    <h1 id="titleHero"><?php echo $tituloHero ?></h1>
    <p id="textHero"><?php echo $textoHero?></p>
</div>