<?php
    try{
        require_once './backend/connectiondb.php';

        $sql = "SELECT * from infos";
        $stmt = $pdo->query($sql);
        $infos =  $stmt->fetch();
        
    } catch(PDOException $e){
        die("Erro ao buscar depoimentos" . $e);
    }

    $telefoneInfo = $infos['telefone'];
    $celularInfo = $infos['celular'];
    $enderecoInfo = $infos['endereco'];
    $imgInfos = $infos['imagemLocal'];    
?>