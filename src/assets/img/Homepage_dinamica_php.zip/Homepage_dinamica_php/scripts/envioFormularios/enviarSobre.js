const formSobre = document.getElementById('formSobre');
const btnSobre = document.getElementById('btnSobre');
const urlSobre = './backend/enviarSobre.php';

const textoSobre = document.getElementById('textoSobre');
const imgSobre = document.getElementById('imgSobre');
const trixSobre = document.getElementById('trixSobre');


btnSobre.addEventListener('click', async (event) => {

    event.preventDefault();

    try{
        const formData = new FormData(formSobre);

        const response = await fetch(urlSobre, {
            method: 'POST',
            body: formData
        });

        if(response.ok){
            alert("Sobre atualizado com sucesso!");
            textoSobre.value = '';
            imgSobre.value = '';
            trixSobre.innerHTML = '';
        }
    }catch(error){
        alert(`Erro ao atualizar sobre! ${error}`);
    }
});