const formInfos = document.getElementById('formInfos');
const btnInfos = document.getElementById('btnInfos');
const urlInfos = './backend/enviarInfos.php';

const telefoneInfos = document.getElementById('telefoneInfos');
const celularInfos = document.getElementById('celularInfos');
const enderecoInfos = document.getElementById('enderecoInfos');
const imgInfos = document.getElementById('imgInfos');


btnInfos.addEventListener('click', async (event) => {

    event.preventDefault();

    try{
        const formData = new FormData(formInfos);

        const response = await fetch(urlInfos, {
            method: 'POST',
            body: formData
        });

        if(response.ok){
            alert("Infos atualizadas com sucesso!");
            telefoneInfos.value = '';
            celularInfos.value = '';
            enderecoInfos.value = '';
            imgInfos.innerHTML = '';
        }
    }catch(error){
        alert(`Erro ao atualizar infos! ${error}`);
    }
});