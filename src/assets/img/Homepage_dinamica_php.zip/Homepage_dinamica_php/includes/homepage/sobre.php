<div id="sobre">
    <img id="imgSobre" src="<?php echo $imagemSobre ?>" alt="">
    <h1 id="titleSobre">Sobre nós</h1>
    <div id="textoSobre"><?php echo $textoSobre ?></div>
</div>