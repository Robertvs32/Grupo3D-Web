<div id="header">
    <a id="linkImgHeader" href="./homepage.php"><img id="imgHeader" src="./img/logo.jpg" alt=""></a>
    <button id="btnHamb"><img src="./img/btnHamb.jpg" alt=""></button>
    <nav id="navHeader">
        <ul id="ulHeader">
            <li class="liHeader"><a href="./painel.php">Painel ADM</a></li>
        </ul>
    </nav>
</div>