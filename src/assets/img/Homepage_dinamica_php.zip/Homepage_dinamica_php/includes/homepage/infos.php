<div id="infos">
    <h2 id="titleInfos">Informações e contatos</h2>
    <div id="contatos">
        <div class="cardContato">
            <h3 class="titleContato">Telefone</h3>
            <p class="textContato"><?php echo $telefoneInfo ?></p>
        </div>

        <div class="cardContato">
            <h3 class="titleContato">Celular</h3>
            <p class="textContato"><?php echo $celularInfo ?></p>
        </div>

        <div class="cardContato">
            <h3 class="titleContato">Localização</h3>
            <p class="textContato"><?php echo $telefoneInfo ?></p>
        </div>

        <h3 id="titleImgLocal">Foto local</h3>

        <img id="imgLocal" src="<?php echo $imgInfos ?>" alt="">

    </div>
</div>