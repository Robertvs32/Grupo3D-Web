<h2 class=tituloSecao>SOBRE NÓS</h2>

<form id="formSobre" class="forms">

    <label for="textoSobre" class="labelForm">Texto</label>
    <input id="textoSobre" name="textoSobre" class="inputForm" type="hidden">
    <trix-toolbar id="toolbarSobre" class="toolbarStyle"></trix-toolbar>
    <trix-editor id="trixSobre" class="editorTrix" input="textoSobre" toolbar="toolbarSobre"></trix-editor>

    <label for="imgSobre" class="labelForm">Imagem</label>
    <input id="imgSobre" class="inputFile" name="imgSobre" type="file">

    <div class="btns">
        <button id="btnSobre" type="submit">Atualizar</button>
        <button type="reset">Limpar</button>
    </div>
</form>

