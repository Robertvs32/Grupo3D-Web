<?php
    $telefone_Infos = $_POST['telefoneInfos'];
    $celular_Infos = $_POST['celularInfos'];
    $endereco_Infos = $_POST['enderecoInfos'];
    $img_Infos = $_FILES['imgInfos'];
    $caminho_db = NULL;

    if(isset($img_Infos) && $img_Infos['error'] === UPLOAD_ERR_OK){
        $caminhoTemporario = $img_Infos['tmp_name'];
        $extensao = pathinfo($img_Infos['name'], PATHINFO_EXTENSION);
        $caminho_final = '../uploads/imagemInfos' . '.' . strtolower($extensao);
        
        if(move_uploaded_file($caminhoTemporario, $caminho_final)){
            $caminho_db = './uploads/imagemInfos' . '.' . strtolower($extensao);  
        }
    }
    try{
        require_once './connectiondb.php';
    
        if($telefone_Infos != ''){
            $sql = "UPDATE infos set telefone = :telefone_Infos where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':telefone_Infos', $telefone_Infos);
            $stmt->execute();
        }
        if($celular_Infos != ''){
            $sql = "UPDATE infos set celular = :celular_Infos where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':celular_Infos', $celular_Infos);
            $stmt->execute();
        }
        if($endereco_Infos != ''){
            $sql = "UPDATE infos set endereco = :endereco_Infos where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':endereco_Infos', $endereco_Infos);
            $stmt->execute();
        }
        if($caminho_db !== NULL){
            $sql = "UPDATE infos set imagemLocal = :caminho_db where id = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':caminho_db', $caminho_db);
            $stmt->execute();
        }
    }catch(PDOException $e){
        echo"Erro ao enviar para o banco de dados!" . $e->getMessage();
    }
?>