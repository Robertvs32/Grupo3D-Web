<div id="equipe">

    <h2 id="titleEquipe">Equipe</h2>
    
    <div class="card_equipe">
        <img class="img_cardEquipe" src="<?php echo $imgFunc1 ?>" alt="">
        <h3 class="titleFuncionario"><?php echo $nomeFunc1 ?></h3>
        <p class="textFuncionario"><?php echo $textoFunc1 ?></p>
        <div class="social">
            <p class="textSocial">Instagram</p>
            <p class="textSocialUser"><?php echo $instaFunc1 ?></p>
        </div>
    </div>

    <div class="card_equipe">
        <img class="img_cardEquipe" src="<?php echo $imgFunc2 ?>" alt="">
        <h3 class="titleFuncionario"><?php echo $nomeFunc2 ?></h3>
        <p class="textFuncionario"><?php echo $textoFunc2 ?></p>
        <div class="social">
            <p class="textSocial">Instagram</p>
            <p class="textSocialUser"><?php echo $instaFunc2 ?></p>
        </div>
    </div>
</div>